<?php
define ( 'PROJECT_MODULE', 'Admin' );
define ( 'PROJECT_TITLE', 'Hash Coder' );
define ( 'PROJECT_SHORT_TITLE', 'HashCoder' );
define ( 'PROJECT_PREFIX', 'HC' );
define ( 'ERROR_CODE_LOGIN', 'bG9naW4gZXJyb3I=' );
define ( 'ERROR_MSG_LOGIN', 'The email address or password you entered is not valid' );
define ( 'ERROR_CODE_BLOCKED', 'bG9naW4gYmxvY2tlZA==' );
define ( 'ERROR_MSG_BLOCKED', 'Sorry! your account is temporary blocked. Please try after 10 minutes.' );
?>